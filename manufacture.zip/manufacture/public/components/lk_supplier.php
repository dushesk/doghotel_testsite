
<div class="sidebar">
    <button class='button' onclick='show_info(this.value)' value='sup_info'>Личные данные</button>
    <button class='button' onclick='show_info(this.value)' value='sup_orders'>Заказы</button>
    <button class='button' onclick='show_info(this.value)' value='sett'>Настройки</button>
</div>
<div class="main_content" id="main">
    <div id="message"></div>
    <div id="main_content">
    <script> 
        show_info('sup_info');    
    </script>
    </div>
</div>