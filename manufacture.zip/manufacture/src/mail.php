<?php 



if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Отправка на почту
    $to = $_SESSION['email'];
    $subject = "Подписка на новости";
    $message = "Теперь вы сможете следить за нашими актуальными новостями!";

    // Опциональные заголовки
    $headers = "From: dasche9v@littledoghotel.ru\r\n";
    $headers .= "Reply-To: ".$to."\r\n";
    $headers .= "X-Mailer: PHP/".phpversion();

    // Отправка письма
    if (!mail($to, $subject, $message, $headers)) {
        echo "Ошибка отправки письма на адрес ".$to;
    }
    
    exit;
}

?>