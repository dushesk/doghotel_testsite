
<div class="sidebar">
    <button class='button' onclick='show_info(this.value)' value='adm_db'>База данных</button>
    <button class='button' onclick='show_info(this.value)' value='stats'>Статистика</button>
    <button class='button' onclick='show_info(this.value)' value='sett'>Настройки</button>            
    
</div>
<div class="main_content" id="main">
    <div id="main_content">
    <script> 
        show_info('adm_db');    
    </script>
    </div>
    
</div>
